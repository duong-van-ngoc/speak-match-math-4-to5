import Phaser from 'phaser';
import { TextureKeys, AudioKeys } from '../consts/Keys';
import { GameConstants } from '../consts/GameConstants';
import { GameUtils } from '../utils/GameUtils';
import { IdleManager } from '../utils/IdleManager';
import AudioManager from '../audio/AudioManager';
import { showGameButtons } from '../main';
import { setGameSceneReference, resetVoiceState } from '../utils/rotateOrientation';
import { changeBackground } from '../utils/BackgroundManager';

/**
 * SceneBase - Abstract class chứa logic chung giữa các scene
 * Giúp tránh duplicate code và dễ bảo trì
 */
export default abstract class SceneBase extends Phaser.Scene {
    // --- SHARED PROPERTIES ---
    protected idleManager!: IdleManager;
    protected handHint!: Phaser.GameObjects.Image;
    protected isGameActive: boolean = false;
    protected bgm!: Phaser.Sound.BaseSound;
    protected isHintActive: boolean = false;

    // --- ABSTRACT METHODS (Subclasses must implement) ---
    protected abstract createUI(): void;
    protected abstract initGameFlow(): void;
    protected abstract showIdleHint(): void;

    // === SHARED METHODS ===

    protected setupSystem(): void {
        resetVoiceState();
        (window as any).gameScene = this;
        setGameSceneReference(this);

        this.idleManager = new IdleManager(GameConstants.IDLE.THRESHOLD, () => {
            this.showIdleHint();
        });

        this.input.on('pointerdown', () => {
            this.resetIdleState();
        });
    }

    protected setupBackgroundAndAudio(bgImagePath: string = 'assets/images/bg/backgroug_game.png'): void {
        changeBackground(bgImagePath);

        if (this.sound.get(AudioKeys.BgmNen)) {
            this.sound.stopByKey(AudioKeys.BgmNen);
        }
        this.bgm = this.sound.add(AudioKeys.BgmNen, { loop: true, volume: 0.25 });
    }

    protected createHandHint(): void {
        this.handHint = this.add.image(0, 0, TextureKeys.HandHint)
            .setDepth(200)
            .setAlpha(0)
            .setScale(0.7);
    }

    protected resetIdleState(): void {
        this.idleManager.reset();
        if (this.isHintActive && this.handHint) {
            this.isHintActive = false;
            this.tweens.killTweensOf(this.handHint);
            this.handHint.setAlpha(0).setPosition(-200, -200);
        }
    }

    protected animateHandHintTo(targetX: number, targetY: number): void {
        if (!this.isGameActive || this.isHintActive) return;

        this.isHintActive = true;
        this.handHint.setPosition(GameUtils.getW(this) + 100, GameUtils.getH(this));
        this.handHint.setAlpha(0);

        const IDLE = GameConstants.IDLE;

        this.tweens.chain({
            targets: this.handHint,
            tweens: [
                {
                    alpha: 1,
                    x: targetX + IDLE.OFFSET_X,
                    y: targetY + IDLE.OFFSET_Y,
                    duration: IDLE.FADE_IN,
                    ease: 'Power2'
                },
                { scale: 0.5, duration: IDLE.SCALE, yoyo: true, repeat: 2 },
                {
                    alpha: 0,
                    duration: IDLE.FADE_OUT,
                    onComplete: () => {
                        this.isHintActive = false;
                        this.idleManager.reset();
                        this.handHint.setPosition(-200, -200);
                    }
                }
            ]
        });
    }

    protected handleWake(): void {
        this.idleManager.reset();
        if (this.input.keyboard) this.input.keyboard.enabled = true;
        if (this.bgm && !this.bgm.isPlaying) this.bgm.play();
    }

    protected cleanupScene(): void {
        this.events.off('wake', this.handleWake, this);
        if (this.bgm && this.bgm.isPlaying) this.bgm.stop();
        if (this.idleManager) this.idleManager.stop();
    }

    protected startWithAudio(onStart: () => void): void {
        AudioManager.loadAll().then(() => {
            if (AudioManager.isUnlocked) {
                onStart();
            } else {
                this.input.once('pointerdown', () => {
                    AudioManager.unlockAudio();
                    onStart();
                });
            }
        });
    }

    protected playBgm(): void {
        if (this.bgm && !this.bgm.isPlaying) this.bgm.play();
    }

    protected showButtons(): void {
        showGameButtons();
    }
}
